# ppo_train.py

from stable_baselines3 import PPO
from stable_baselines3.common.env_util import make_vec_env
from custom_env import RacingEnv

# 환경 초기화
env = RacingEnv()

# PPO 모델 초기화
model = PPO("MlpPolicy", env, verbose=1)

# 모델 학습
model.learn(total_timesteps=100000)

# 모델 저장
model.save("ppo_racing_model")

# 환경 종료
env.close()