# custom_env.py

import gym
import numpy as np
from gym import spaces

class AICarEnv(gym.Env):
    def __init__(self):
        super(AICarEnv, self).__init__()

        # Define action and observation space
        # Actions: [steer_left, steer_right, accelerate, brake]
        self.action_space = spaces.Discrete(4)

        # Observations: [distance_to_left, distance_to_right, speed, angle_to_track]
        self.observation_space = spaces.Box(low=np.array([0, 0, 0, -np.pi]),
                                             high=np.array([100, 100, 50, np.pi]), dtype=np.float32)

        self.reset()

    def reset(self):
        # Reset the car's state
        self.state = np.array([50, 50, 0, 0], dtype=np.float32)  # Initial state: centered, stopped, aligned
        self.done = False
        return self.state

    def step(self, action):
        distance_to_left, distance_to_right, speed, angle_to_track = self.state

        # Action effects
        if action == 0:  # Steer left
            angle_to_track -= 0.1
        elif action == 1:  # Steer right
            angle_to_track += 0.1
        elif action == 2:  # Accelerate
            speed += 1
        elif action == 3:  # Brake
            speed = max(0, speed - 1)

        # Update state
        angle_to_track = np.clip(angle_to_track, -np.pi, np.pi)
        speed = np.clip(speed, 0, 50)

        distance_to_left = max(0, distance_to_left - speed * np.abs(np.sin(angle_to_track)))
        distance_to_right = max(0, distance_to_right - speed * np.abs(np.cos(angle_to_track)))

        self.state = np.array([distance_to_left, distance_to_right, speed, angle_to_track], dtype=np.float32)

        # Calculate reward
        reward = speed * 0.1 - abs(angle_to_track) * 0.5
        if distance_to_left <= 0 or distance_to_right <= 0:
            self.done = True
            reward -= 100  # Penalty for crashing

        return self.state, reward, self.done, {}

    def render(self, mode='human'):
        print(f"State: {self.state}")

    def close(self):
        pass
