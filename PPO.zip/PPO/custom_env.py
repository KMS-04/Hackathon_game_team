# custom_env.py

import gym
from gym import spaces
import numpy as np
from cars import AICar, PlayerCar
from game_info import GameInfo

class RacingEnv(gym.Env):
    def __init__(self):
        super(RacingEnv, self).__init__()
        
        # 행동 공간: [가속, 회전] (가속: -1~1, 회전: -1~1)
        self.action_space = spaces.Box(low=-1, high=1, shape=(2,), dtype=np.float32)
        
        # 관찰 공간: 차량의 상태 + AI 차량의 상대 위치 등
        obs_space_dim = 10  # 관찰 상태 차원 (위치, 속도, 각도 등)
        self.observation_space = spaces.Box(low=-np.inf, high=np.inf, shape=(obs_space_dim,), dtype=np.float32)
        
        # 차량과 게임 초기화
        self.player_car = PlayerCar(max_vel=5, rotation_vel=2.5)
        self.ai_car = AICar(max_vel=5, rotation_vel=2.5, path=[])
        self.game_info = GameInfo()

    def reset(self):
        # 게임과 차량 상태 초기화
        self.player_car.reset()
        self.ai_car.reset()
        self.game_info.reset()
        
        # 초기 관찰값 반환
        return self._get_obs()

    def step(self, action):
        # 행동 적용: action = [가속, 회전]
        accel, rotation = action
        if accel > 0:
            self.player_car.move_forward()
        elif accel < 0:
            self.player_car.move_backward()
        
        if rotation > 0:
            self.player_car.rotate(right=True)
        elif rotation < 0:
            self.player_car.rotate(left=True)
        
        # AI 차량 이동
        self.ai_car.move()

        # 보상 계산 및 종료 조건 확인
        reward = self._calculate_reward()
        done = self.game_info.is_ready_for_finish(self.player_car)

        # 다음 상태 계산
        obs = self._get_obs()
        return obs, reward, done, {}

    def _get_obs(self):
        # 플레이어와 AI 차량의 상태를 포함한 관찰 공간
        player_state = [
            self.player_car.x, self.player_car.y, self.player_car.vel, self.player_car.angle
        ]
        ai_state = [
            self.ai_car.x, self.ai_car.y, self.ai_car.vel, self.ai_car.angle
        ]
        return np.array(player_state + ai_state, dtype=np.float32)

    def _calculate_reward(self):
        # 플레이어 차량의 진행 방향 및 속도를 기반으로 보상 계산
        reward = self.player_car.vel  # 기본적으로 속도를 보상으로 사용
        if self.player_car.collide(self.ai_car.border_mask):
            reward -= 10  # AI 차량과 충돌하면 큰 페널티
        return reward

    def render(self, mode="human"):
        # 선택적으로 게임을 렌더링할 수 있습니다.
        pass