# ppo_train.py

import gym
import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
from torch.distributions import Categorical
from custom_env import AICarEnv

# Hyperparameters
learning_rate = 0.0003
gamma = 0.99
lmbda = 0.95
eps_clip = 0.2
K_epochs = 4
rollout_len = 2048

class PolicyNetwork(nn.Module):
    def __init__(self, state_dim, action_dim):
        super(PolicyNetwork, self).__init__()
        self.fc1 = nn.Linear(state_dim, 256)
        self.fc2 = nn.Linear(256, 256)
        self.fc_pi = nn.Linear(256, action_dim)
        self.fc_v = nn.Linear(256, 1)

    def forward(self, x):
        x = torch.relu(self.fc1(x))
        x = torch.relu(self.fc2(x))
        pi = self.fc_pi(x)
        v = self.fc_v(x)
        return pi, v

    def get_action(self, state):
        logits, _ = self.forward(state)
        probs = torch.softmax(logits, dim=-1)
        dist = Categorical(probs)
        action = dist.sample()
        return action.item(), dist.log_prob(action)

    def evaluate(self, state, action):
        logits, value = self.forward(state)
        probs = torch.softmax(logits, dim=-1)
        dist = Categorical(probs)
        action_logprobs = dist.log_prob(action)
        dist_entropy = dist.entropy()
        return action_logprobs, torch.squeeze(value), dist_entropy

class PPOAgent:
    def __init__(self, state_dim, action_dim):
        self.policy = PolicyNetwork(state_dim, action_dim).to(device)
        self.optimizer = optim.Adam(self.policy.parameters(), lr=learning_rate)
        self.policy_old = PolicyNetwork(state_dim, action_dim).to(device)
        self.policy_old.load_state_dict(self.policy.state_dict())
        self.MseLoss = nn.MSELoss()

    def update(self, memory):
        states = torch.tensor(memory['states'], dtype=torch.float).to(device)
        actions = torch.tensor(memory['actions']).to(device)
        rewards = memory['rewards']
        old_logprobs = torch.tensor(memory['logprobs']).to(device)

        # Compute discounted rewards and GAE
        rewards_to_go = []
        discounted_reward = 0
        for reward, done in zip(reversed(rewards), reversed(memory['dones'])):
            if done:
                discounted_reward = 0
            discounted_reward = reward + gamma * discounted_reward
            rewards_to_go.insert(0, discounted_reward)
        rewards_to_go = torch.tensor(rewards_to_go, dtype=torch.float).to(device)

        advantages = []
        gae = 0
        values = self.policy_old.forward(states)[1].detach()
        for t in reversed(range(len(rewards))):
            delta = rewards[t] + gamma * (values[t + 1] if t + 1 < len(rewards) else 0) - values[t]
            gae = delta + gamma * lmbda * gae
            advantages.insert(0, gae)
        advantages = torch.tensor(advantages, dtype=torch.float).to(device)

        for _ in range(K_epochs):
            logprobs, state_values, dist_entropy = self.policy.evaluate(states, actions)

            ratios = torch.exp(logprobs - old_logprobs.detach())
            surr1 = ratios * advantages
            surr2 = torch.clamp(ratios, 1 - eps_clip, 1 + eps_clip) * advantages
            
            loss = -torch.min(surr1, surr2) + 0.5 * self.MseLoss(state_values, rewards_to_go) - 0.01 * dist_entropy

            self.optimizer.zero_grad()
            loss.mean().backward()
            self.optimizer.step()

        self.policy_old.load_state_dict(self.policy.state_dict())

if __name__ == "__main__":
    env = AICarEnv()
    state_dim = env.observation_space.shape[0]
    action_dim = env.action_space.n

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    agent = PPOAgent(state_dim, action_dim)

    memory = {
        'states': [],
        'actions': [],
        'rewards': [],
        'logprobs': [],
        'dones': []
    }

    for episode in range(1000):
        state = env.reset()
        done = False
        score = 0

        while not done:
            state_tensor = torch.tensor(state, dtype=torch.float).to(device)
            action, logprob = agent.policy_old.get_action(state_tensor)

            next_state, reward, done, _ = env.step(action)
            memory['states'].append(state)
            memory['actions'].append(action)
            memory['rewards'].append(reward)
            memory['logprobs'].append(logprob)
            memory['dones'].append(done)

            state = next_state
            score += reward

            if len(memory['states']) >= rollout_len:
                agent.update(memory)
                memory = {'states': [], 'actions': [], 'rewards': [], 'logprobs': [], 'dones': []}

        print(f"Episode {episode}, Score: {score}")
